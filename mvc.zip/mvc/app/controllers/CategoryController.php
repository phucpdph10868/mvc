<?php 
namespace App\Controllers;

class CategoryController
{
    public function index()
    {
        return "Category page here!";
    }

    public function about()
    {
        return "About Category page here!";
    }
}

?>