<?php 
namespace App\Controllers;

use App\Models\Category;

class HomeController
{
    public function index()
    {
        $cates = Category::all();
        include './app/views/cate-list.php';

    }

    public function about()
    {
        return "About page here!";
    }
}

?>