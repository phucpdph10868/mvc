<?php 
namespace App\Controllers;

class ProductController
{
    public function detail()
    {
        return "Detail product!";
    }

    public function about()
    {
        return "About product page here!";
    }
}

?>