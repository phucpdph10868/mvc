<?php 
namespace App\Models;

class Category extends BaseModel{
    protected $tableName = 'categories';
}



?>