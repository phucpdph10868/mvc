<?php 

$url = isset($_GET['url'])==true ? $_GET['url'] : "/";

require_once "./vendor/autoload.php";
// require_once "./app/controllers/HomeController.php";
// require_once "./app/controllers/ProductController.php";
// require_once "./app/controllers/CategoryController.php";
// require_once "./app/models/BaseModel.php";
// require_once "./app/models/Category.php";

use App\Controllers\HomeController;
use App\Controllers\CategoryController;
use App\Controllers\ProductController;


switch($url) {
    case "/":
        $ctr = new HomeController();
        $ctr->index();
        break;
    case "about":
        $ctr = new CategoryController();
        echo $ctr->about();
        break;
    case "detail":
        $ctr = new ProductController();
        echo $ctr->detail();
        break;
    default:
        echo 'Not found!';
        break;
}
?>